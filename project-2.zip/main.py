

#   functions.py

#   Darius Glenn

# Magic 8 Ball teller and Eli's Shipping

# June 22,2022



from random import randrange
rand_num = randrange(0,9)
name = input("What is your full name? ")
asks = input("What is your question you would like to answer? ")
space_index = name.find(" ")
name = name[:space_index]
letter = name[space_index -1]
last_character = name[space_index -1]
if rand_num == 0:
  fortune = "yes - definitely"
elif rand_num == 1:
  fortune = "it is decidely so"
elif rand_num == 2:
  fortune = "without a doubt"
elif rand_num == 3:
  fortune = "reply hazy, try again"
elif rand_num == 4:
  fortune = "ask again later"
elif rand_num == 5:
  fortune = "better not tell you now"
elif rand_num == 6:
 fortune = "My sources say no"
elif rand_num == 7:
  fortune = "Outlook not so good"
elif rand_num == 8:
  fortune = "very doubtful"
if last_character == "s":
  print(f"{name}' Question: {asks}")
else:
  print(f"{name}'s Question: {asks}")
print(f"Magic 8-Ball's answer: {fortune}")
